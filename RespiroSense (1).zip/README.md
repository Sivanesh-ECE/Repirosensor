# RespiroSense
### AI-Powered Nocturnal Respiratory Crisis Predictor — ESP32

> ⚠️ **Medical disclaimer:** RespiroSense is a DIY assistive monitoring
> project built from hobbyist-grade sensors and a small on-device demo
> classifier. It is **not** a certified medical device, has not been
> clinically validated, and must **not** be relied on as the sole means of
> detecting a respiratory emergency (e.g. sleep apnea, asthma attack). Always
> use alongside professional medical supervision and equipment.

RespiroSense continuously listens for respiratory sounds (wheeze, cough,
distress) with an I2S MEMS microphone, tracks chest/torso motion with a
6-axis IMU to estimate respiration rate and restlessness, fuses both signals
with temporal hysteresis into a graded alert level, shows live status on an
OLED, escalates through a 3-stage audio alarm, and pushes Telegram/webhook
notifications over Wi-Fi — all running as pinned FreeRTOS tasks across both
ESP32 cores with automatic peripheral error-recovery.

---

## 1. Folder Structure

```
RespiroSense/
├── README.md                          ← you are here
├── docs/
│   ├── 01_pin_mapping_and_connections.md
│   ├── 02_wiring_and_circuit_diagram.md
│   ├── 03_architecture.md             ← hardware + software architecture
│   ├── 04_logic_flowchart.md
│   └── 05_BOM.md
└── RespiroSense/                      ← Arduino sketch folder (open this in Arduino IDE)
    ├── RespiroSense.ino               ← setup()/loop(), task creation, watchdog
    ├── config.h                       ← pin map, constants, Wi-Fi/Telegram credentials
    ├── model_weights.h / .cpp         ← generated mel-filterbank + NN coefficients (flash)
    ├── utilities.h / .cpp             ← mutexes, queues' data structs, DSP helpers
    ├── logger.h / .cpp                ← thread-safe ring-buffer logger
    ├── audio.h / .cpp                 ← I2S0 mic capture + self-contained FFT + mel features
    ├── edge_ai.h / .cpp               ← on-device dense-NN inference engine
    ├── motion.h / .cpp                ← MPU6050 driver + respiration-rate estimator
    ├── sensor_fusion.h / .cpp         ← audio+motion fusion, graded alert logic
    ├── display.h / .cpp               ← SSD1306 live status rendering
    ├── alarm.h / .cpp                 ← I2S1 amp tone synthesis, 3-stage alarm
    ├── wifi_ctrl.h / .cpp             ← Wi-Fi connect/reconnect
    └── telegram.h / .cpp              ← Telegram bot + webhook alerts, network task
```

> **Arduino IDE requirement:** the sketch folder must be named exactly the
> same as the `.ino` file it contains (`RespiroSense/RespiroSense.ino`) —
> already satisfied above. Open `RespiroSense/RespiroSense.ino`, not the
> repo root.

See `docs/` for the full pin mapping, wiring diagram, circuit diagram,
architecture, logic flowcharts, and BOM.

---

## 2. Required Libraries

Install via **Arduino IDE → Sketch → Include Library → Manage Libraries**:

| Library | Author | Tested version | Purpose |
|---|---|---|---|
| Adafruit SSD1306 | Adafruit | ≥2.5.x | OLED driver |
| Adafruit GFX Library | Adafruit | ≥1.11.x | Graphics primitives (dependency of SSD1306) |
| Adafruit MPU6050 | Adafruit | ≥2.2.x | IMU driver |
| Adafruit Unified Sensor | Adafruit | ≥1.1.x | Dependency of Adafruit MPU6050 |
| ArduinoJson | Benoit Blanchon | ≥6.21.x | Telegram/webhook JSON payloads |

> **No FFT library required.** `audio.cpp` includes a small self-contained
> radix-2 Cooley-Tukey FFT written directly into the firmware, so there is
> nothing extra to install for audio feature extraction and no risk of a
> "library not found" error or an FFT-library API-version mismatch.

Built into the **ESP32 Arduino core** (no separate install needed): `WiFi.h`,
`WiFiClientSecure.h`, `HTTPClient.h`, `Wire.h`, `driver/i2s.h`,
FreeRTOS (`freertos/FreeRTOS.h` etc., available implicitly via `Arduino.h`).

### Board package
Install **esp32 by Espressif Systems** via **Boards Manager** (Arduino IDE →
Tools → Board → Boards Manager, search "esp32"). Tested with core **2.0.x
and 3.0.x**; the firmware avoids core-version-specific APIs (e.g. the
hardware task watchdog) precisely so it compiles cleanly on either.

---

## 3. Configuration (edit before flashing)

Open `RespiroSense/config.h` and set:

```cpp
#define WIFI_SSID          "YOUR_WIFI_SSID"
#define WIFI_PASSWORD      "YOUR_WIFI_PASSWORD"

#define TELEGRAM_BOT_TOKEN "YOUR_TELEGRAM_BOT_TOKEN"   // from @BotFather
#define TELEGRAM_CHAT_ID   "YOUR_TELEGRAM_CHAT_ID"      // your chat/group id

#define WEBHOOK_URL         ""   // optional, e.g. an IFTTT/n8n/Home Assistant URL
```

If you don't want Telegram alerts, leave the token as the default
placeholder string — `telegramSendMessage()` detects the unconfigured value
and silently skips sending (this is a **runtime guard**, not a compile-time
stub — the firmware still builds and runs fully without it).

---

## 4. Upload Guide

1. **Board settings** (Tools menu):
   - Board: **ESP32 Dev Module**
   - Upload Speed: 921600 (or 115200 if you see upload errors)
   - Flash Size: 4MB (or your board's actual size)
   - Partition Scheme: Default (or "Minimal SPIFFS" if you need more app space)
2. Connect the ESP32 via USB, select the correct **Port**.
3. Open `RespiroSense/RespiroSense.ino` in Arduino IDE.
4. Click **Verify/Compile** first to confirm all libraries are installed.
5. Click **Upload**. If upload fails to start, hold the **BOOT** button on
   the board while upload begins, release once flashing starts (common on
   some DevKit clones).
6. Open **Serial Monitor** at **115200 baud** to watch boot logs.

---

## 5. Testing Guide

| Test | Expected result |
|---|---|
| Power on, watch Serial | `[BOOT]` lines show `audio=1 motion=1 display=1 alarm=1 ai=1 fusion=1` |
| OLED | Shows "RespiroSense v1.0" briefly, then live status screen |
| Speak/blow near INMP441 | `Audio:` line on OLED changes class/confidence |
| Tap the board / breathe near MPU6050 | `Resp:` bpm value appears after ~5–20s once ≥2 breath cycles are detected |
| Shake board vigorously | `Move sd:` value rises; may trigger ADVISORY alert |
| Force repeated "Distress" (see note below) | OLED banner inverts to WARNING/CRITICAL, speaker beeps escalate |
| Press BOOT button during ADVISORY/WARNING | Alarm snoozes for 5 minutes (CRITICAL cannot be snoozed by design) |
| Disconnect Wi-Fi | `[----]` shown in header instead of `[WiFi]`; reconnects automatically within `WIFI_RECONNECT_INTERVAL_MS` |
| Configure Telegram, force WARNING+ | Telegram message received with class, confidence, bpm, movement |

> Since the shipped classifier uses **demonstration weights** (see §6), it
> will not reliably classify real wheeze/cough/distress sounds out of the
> box. Use loud sustained tones/noise near the mic and observe the
> `scores[]` array via `LOGD` in `edge_ai.cpp` to confirm the inference
> pipeline itself (FFT → mel → NN → softmax) is functioning end-to-end.

---

## 6. Swapping in a trained Edge Impulse model

The shipped `edge_ai.cpp` ships a **fully functional**, self-contained
13→16→5 dense neural network with deterministic demo weights
(`model_weights.h/.cpp`) so the project compiles and runs standalone with
zero external dependencies. These weights are **not clinically trained** —
replace them for real-world accuracy:

1. Collect/label audio clips for Normal / Wheeze / Cough / Distress classes
   and train an Edge Impulse project (Audio → MFCC/MFE block → NN classifier).
2. Export as an **Arduino library** (Edge Impulse Studio → Deployment →
   Arduino Library).
3. Add the exported `.zip` via **Sketch → Include Library → Add .ZIP
   Library**.
4. In `edge_ai.cpp`, replace the body of `edgeAiRunInference()` with a call
   into the exported SDK's `run_classifier()`, mapping
   `result.classification[i].value` into `outResult.scores[i]` and picking
   the argmax as `outResult.classId`. Keep the existing low-RMS-silence
   guard if desired.
5. You can then delete `model_weights.h/.cpp` and the internal FFT/mel code
   in `audio.cpp` in favor of the Edge Impulse SDK's own signal processing,
   or keep both and A/B compare.

---

## 7. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| OLED stays blank | Wrong I2C address or wiring | Confirm SSD1306 is `0x3C` (some modules are `0x3D` — edit `OLED_ADDR` in `config.h`); check SDA/SCL wiring |
| `[BOOT] ... motion=0` | MPU6050 not detected | Check 3V3/GND/SDA/SCL wiring; confirm address `0x68` (tie AD0 low) |
| No sound from speaker | Amp on 3.3V instead of 5V, or GAIN/SD miswired | Power MAX98357A `Vin` from ESP32 **5V/VIN**, confirm `PIN_SPK_SD_ENABLE` (GPIO13) wiring |
| Garbled/no I2S mic data | WS/SCK/SD swapped, or L/R not grounded | Re-check pin map in `docs/01_pin_mapping_and_connections.md`; L/R **must** be tied to GND |
| Board won't enter upload mode | Some GPIO strap conflict at boot | Hold BOOT while clicking Upload, release after flashing starts; ensure nothing else pulls GPIO0 low unintentionally at boot besides the intended button |
| Wi-Fi never connects | Wrong SSID/password, or 5GHz-only network | ESP32 only supports 2.4GHz Wi-Fi; double-check `config.h` credentials |
| Telegram messages not arriving | Bot token/chat id wrong, or bot not started | Message your bot at least once in Telegram first (bots can't message you until you've messaged them), verify token via `https://api.telegram.org/bot<token>/getMe` |
| Random reboots / brownout | Amplifier peak current sagging 3.3V/5V rail | Use a proper 5V/2A supply; add a bulk capacitor (100–470µF) across the amp's 5V/GND pins |
| High false-alarm rate | Demo model weights, not trained | See §6 — train and swap in a real Edge Impulse model |
| Heap slowly dropping over days | Check `[WDT] Heap free:` log trend | Static buffers mean this is unlikely from firmware; if seen, capture Serial log and file an issue with the trend data |

---

## 8. Safety & Privacy Notes

- Audio is processed **entirely on-device**; raw audio is never transmitted
  over Wi-Fi — only classification results, respiration rate, and movement
  statistics are sent in alerts.
- The CRITICAL alarm stage is intentionally **not user-silenceable** from
  the device; only physically powering off the unit stops it.
- Store your Telegram bot token like a password — anyone with it can send
  messages as your bot.
