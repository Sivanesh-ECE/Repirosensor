# RespiroSense — Pin Mapping & Connection Tables

## Conflict Analysis Summary

| Concern | Check | Result |
|---|---|---|
| I2C address collision | MPU6050 (0x68) vs SSD1306 (0x3C) | No collision — safe to share SDA/SCL |
| I2S peripheral collision | Mic (RX) vs Amp (TX) | ESP32 has 2 independent I2S controllers → mic on **I2S0**, amp on **I2S1**. No DMA/channel conflict. |
| Boot-strapping pins | GPIO0, 2, 12, 15 | GPIO0 reused *only* as a debounced button, read well after boot. GPIO2 used only as a status LED (safe, standard on most DevKits). GPIO12/15 **unused** entirely to avoid flash-voltage / boot-mode issues. |
| Flash-reserved pins | GPIO6–11 | Not used anywhere. |
| Input-only pins | GPIO34–39 | Not required by any output signal; not used. |
| JTAG strap pins | GPIO13 (MTCK), GPIO14 (MTMS) | Used for amp-enable / I2S LRC. Safe for designs that don't use JTAG (standard ESP32 DevKit practice). |
| Power budget | 3.3V rail vs 5V rail | Mic, IMU, OLED run on 3.3V (low current, <30 mA combined). Amplifier draws bursts up to ~1.4A into a 4Ω/4W speaker → **powered from 5V (VIN/USB rail)**, not the 3.3V regulator, to avoid brownout. |
| Shared-bus race conditions | MPU6050 + SSD1306 on same I2C bus, read/written from different FreeRTOS tasks | Resolved with a FreeRTOS mutex (`i2cMutex`) guarding every I2C transaction. |

## Final Pin Map

| Function | Signal | ESP32 GPIO | Notes |
|---|---|---|---|
| I2C bus (shared) | SDA | GPIO21 | MPU6050 + SSD1306 |
| I2C bus (shared) | SCL | GPIO22 | 400 kHz fast mode |
| INMP441 mic (I2S0, RX) | WS / LRCLK | GPIO25 | |
| INMP441 mic (I2S0, RX) | SCK / BCLK | GPIO26 | |
| INMP441 mic (I2S0, RX) | SD (data out of mic) | GPIO33 | |
| INMP441 mic | L/R | — | Hard-wired to **GND** (selects left/mono channel) |
| MAX98357A amp (I2S1, TX) | BCLK | GPIO27 | |
| MAX98357A amp (I2S1, TX) | LRC | GPIO14 | |
| MAX98357A amp (I2S1, TX) | DIN | GPIO32 | |
| MAX98357A amp | SD (shutdown/enable) | GPIO13 | HIGH = enabled, LOW = shutdown (power save) |
| MAX98357A amp | GAIN | — | Left floating → default 9 dB gain |
| MPU6050 | INT | GPIO4 | Optional data-ready interrupt (polled fallback used in firmware) |
| Silence / snooze button | BTN | GPIO0 | Reuses onboard BOOT button, `INPUT_PULLUP`, debounced |
| Status LED | LED | GPIO2 | Heartbeat blink from `loop()` |

## Power Connections

| Component | Voltage pin | Source | Ground |
|---|---|---|---|
| ESP32 Dev Module | 5V (VIN) or USB | USB / 5V supply | Common GND |
| INMP441 | VDD | 3.3V (ESP32 3V3 pin) | Common GND |
| MPU6050 | VCC | 3.3V (ESP32 3V3 pin) | Common GND |
| SSD1306 OLED | VCC | 3.3V (ESP32 3V3 pin) | Common GND |
| MAX98357A | Vin | **5V** (ESP32 VIN / external 5V, NOT 3V3) | Common GND |
| 4W Speaker | + / − | MAX98357A OUT+ / OUT− | — |

> All GND pins (ESP32, mic, IMU, OLED, amp, speaker return) must be tied to a **single common ground** to avoid ground-loop noise on the analog microphone/amp path.

## Full Connection Table

| From | Pin | To | Pin |
|---|---|---|---|
| ESP32 | 3V3 | INMP441 | VDD |
| ESP32 | GND | INMP441 | GND, L/R |
| ESP32 | GPIO25 | INMP441 | WS |
| ESP32 | GPIO26 | INMP441 | SCK |
| ESP32 | GPIO33 | INMP441 | SD |
| ESP32 | 3V3 | MPU6050 | VCC |
| ESP32 | GND | MPU6050 | GND |
| ESP32 | GPIO21 | MPU6050 | SDA |
| ESP32 | GPIO22 | MPU6050 | SCL |
| ESP32 | GPIO4 | MPU6050 | INT |
| ESP32 | 3V3 | SSD1306 | VCC |
| ESP32 | GND | SSD1306 | GND |
| ESP32 | GPIO21 | SSD1306 | SDA |
| ESP32 | GPIO22 | SSD1306 | SCL |
| ESP32 | VIN (5V) | MAX98357A | Vin |
| ESP32 | GND | MAX98357A | GND |
| ESP32 | GPIO27 | MAX98357A | BCLK |
| ESP32 | GPIO14 | MAX98357A | LRC |
| ESP32 | GPIO32 | MAX98357A | DIN |
| ESP32 | GPIO13 | MAX98357A | SD |
| MAX98357A | OUT+ | Speaker | + |
| MAX98357A | OUT− | Speaker | − |
