# RespiroSense — Hardware & Software Architecture

## Hardware Architecture

```
 ┌────────────┐     I2S0 RX      ┌───────────────────────────────┐
 │  INMP441   │ ───────────────► │                                │
 │ microphone │                  │                                │
 └────────────┘                  │                                │
                                  │          ESP32-WROOM-32        │
 ┌────────────┐     I2C (shared) │      dual-core Xtensa LX6       │
 │  MPU6050   │ ◄──────────────► │   Core0: RT audio + alarm       │
 │  6-axis IMU│                  │   Core1: app logic + network    │
 └────────────┘                  │                                │
                                  │                                │
 ┌────────────┐     I2C (shared) │                                │
 │  SSD1306   │ ◄──────────────► │                                │
 │  OLED 128x64│                 │                                │
 └────────────┘                  │                                │
                                  │                                │
 ┌────────────┐     I2S1 TX      │                                │
 │ MAX98357A  │ ◄─────────────── │                                │
 │ + 4W spkr  │                  └─────────────┬──────────────────┘
 └────────────┘                                │ Wi-Fi 2.4GHz
                                                ▼
                                    Telegram Bot API / Webhook
```

**Power domains:** 3.3V (mic, IMU, OLED, ESP32 logic) and 5V (ESP32 VIN, amplifier).
Both domains share a single common ground plane to keep the microphone's analog
front-end quiet relative to the switching amplifier.

**Bus topology:** two independent I2S engines (mic RX-only on I2S0, amp TX-only
on I2S1) run truly concurrently with separate DMA descriptor rings — this is
the key conflict-avoidance decision, since a single ESP32 I2S peripheral
cannot do simultaneous full-duplex RX+TX in this pin configuration. The I2C
bus is shared between MPU6050 and SSD1306 (different addresses), arbitrated
in software with a mutex since two different FreeRTOS tasks touch it.

## Software Architecture

### FreeRTOS Task Map

| Task | Core | Priority | Stack | Role |
|---|---|---|---|---|
| `AudioCapture` | 0 | highest (24) | 4096 | Blocking I2S0 DMA reads → feature extraction → queue |
| `AudioInfer` | 0 | 3 | 6144 | Dequeue features, run Edge-AI classifier @1 Hz |
| `Alarm` | 0 | 4 | 3072 | Real-time I2S1 tone synthesis for alarm stages |
| `Motion` | 1 | 3 | 3072 | 50 Hz MPU6050 sampling, respiration-rate + movement estimation |
| `Fusion` | 1 | 2 | 3072 | Combines audio class + motion metrics → graded AlertLevel |
| `Display` | 1 | 1 | 3072 | Renders OLED status @~5 Hz |
| `Network` | 1 | 1 | 6144 | Wi-Fi maintenance + rate-limited Telegram/webhook alerts |
| `Watchdog` | 1 | 2 | 2048 | Heartbeat monitoring + automatic peripheral re-init |

Audio-path tasks are pinned to **Core 0** to keep the real-time DMA capture
and time-critical tone synthesis free from Wi-Fi/HTTP jitter, which runs on
**Core 1** alongside the IMU, fusion, and display logic.

### Data Flow (Queues)

```
INMP441 ──► [AudioCapture] ──AudioFeatureFrame──► queue(4) ──► [AudioInfer]
                                                                     │
                                                          InferenceResult
                                                                     │
MPU6050 ──► [Motion] ──MotionMetrics──► queue(4) ────────────► [Fusion]
                                                                     │
                                                            FusionResult
                                                    ┌────────────────┼────────────────┐
                                                    ▼                ▼                ▼
                                              queue(2)          queue(2)          queue(4)
                                             [Display]           [Alarm]         [Network]
```

Each consumer gets its **own** single-reader queue (FreeRTOS queues are
consumed once); the Fusion task fans out its result to all three so a slow
consumer (e.g. Network, blocked on HTTP) never starves Display or Alarm.

### Memory Strategy

- All large buffers (FFT arrays, DMA buffers, mel filterbank/NN weights) are
  statically allocated at compile time — no heap fragmentation risk during
  24/7 operation.
- Model coefficients live in flash (`PROGMEM`) and are read via
  `pgm_read_float()`, not copied into RAM.
- Queues carry small fixed-size structs by value (no dynamic allocation per
  message).
- The Watchdog task logs free heap every 2 s so a slow leak is visible in
  Serial/telemetry long before it becomes critical.

### Error Recovery Strategy

Every peripheral driver exposes a `*Reinit()` function. Each task updates a
per-task heartbeat timestamp on every successful cycle. The Watchdog task
polls these heartbeats; if any task goes silent for `HEARTBEAT_STALE_MS`
(default 5 s), the corresponding peripheral is automatically reinitialized
(I2S driver reinstalled, I2C device re-probed, etc.) without rebooting the
whole device. Wi-Fi has its own independent reconnect loop in `taskNetwork`.
