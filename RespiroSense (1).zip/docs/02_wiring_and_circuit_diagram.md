# RespiroSense — Wiring & Circuit Diagram

## System Block Diagram

```
                         ┌───────────────────────────────────────────┐
                         │                ESP32 DevKit                │
                         │                                             │
  INMP441 ───I2S0 RX───► │ GPIO25 WS  GPIO26 SCK  GPIO33 SD            │
  (mic)                  │                                             │
                         │                                             │
  MPU6050 ◄──I2C───────► │ GPIO21 SDA  GPIO22 SCL   GPIO4 INT          │
  SSD1306 ◄──I2C───────► │ (shared bus, mutex-protected)               │
                         │                                             │
  MAX98357A ◄──I2S1 TX── │ GPIO27 BCLK GPIO14 LRC GPIO32 DIN GPIO13 SD │
   + 4W Speaker          │                                             │
                         │                                             │
  BOOT button ─────────► │ GPIO0 (snooze)                              │
  Status LED  ◄───────── │ GPIO2                                       │
                         │                                             │
                         │        Wi-Fi (2.4 GHz) ─────► Telegram API  │
                         │                                 / Webhook   │
                         └───────────────────────────────────────────┘
```

## Circuit Schematic (ASCII)

```
                3V3 ──────┬───────────────┬───────────────┐
                          │               │               │
                       ┌──┴───┐        ┌──┴───┐        ┌──┴────┐
                       │INMP441│        │MPU6050│        │SSD1306│
                       │  VDD  │        │  VCC  │        │  VCC  │
                       └──┬───┘        └──┬───┘        └──┬────┘
        ESP32 GPIO25──WS──┤            SDA┤──────┬────────┤SDA
        ESP32 GPIO26──SCK─┤            SCL┤──────┼───┬────┤SCL
        ESP32 GPIO33──SD──┤            INT┤       │   │    └───────┐
                       ┌──┴───┐           │       │   │            │
                GND────┤ L/R  │      ESP32 GPIO21─┘   │      ESP32 GPIO22
                       │ GND  │      ESP32 GPIO4───────┘  (both SDA/SCL
                       └──┬───┘                             bus taps)
                          │
                GND ──────┴─────────────────────────────────────────┐
                                                                      │
   5V/VIN ───────────┬─────────────────────────────────────────┐    │
                   ┌──┴─────┐                                   │    │
                   │MAX98357A│                                  │    │
                   │  Vin    │                                  │    │
        ESP32 GPIO27─BCLK    │                                  │    │
        ESP32 GPIO14─LRC     │                                  │    │
        ESP32 GPIO32─DIN     │                                  │    │
        ESP32 GPIO13─SD      │                                  │    │
                   │ OUT+ ───┼──► Speaker (+)                    │    │
                   │ OUT− ───┼──► Speaker (−)                    │    │
                   │  GND ───┼───────────────────────────────────┘    │
                   └─────────┘                                        │
                                                                       │
                          GND (common return, all modules) ───────────┘
```

## Physical Wiring Diagram (breadboard-style description)

1. Place the ESP32 DevKit in the center of the breadboard, straddling the center gap.
2. Run a red rail to 3V3 and a blue/black rail to GND from the ESP32's 3V3 and GND pins.
3. INMP441: VDD→3V3 rail, GND→GND rail, L/R→GND rail (mono/left channel), WS→GPIO25, SCK→GPIO26, SD→GPIO33.
4. MPU6050: VCC→3V3 rail, GND→GND rail, SDA→GPIO21, SCL→GPIO22, INT→GPIO4.
5. SSD1306: VCC→3V3 rail, GND→GND rail, SDA→GPIO21 (same bus as MPU6050), SCL→GPIO22 (same bus).
6. MAX98357A: Vin→**5V/VIN pin** (not 3V3 rail — the amp needs the higher rail for full 4W output), GND→GND rail, BCLK→GPIO27, LRC→GPIO14, DIN→GPIO32, SD→GPIO13, GAIN→leave unconnected (floating = 9 dB default).
7. Speaker: 2-wire connection to MAX98357A OUT+ / OUT−.
8. No extra wiring needed for the BOOT button/status LED — they are already on the ESP32 DevKit board (GPIO0 and GPIO2 respectively on most boards).

> **Tip:** Keep the INMP441's wires short and away from the I2S amplifier/speaker wires to minimize electrical noise coupling into the microphone signal.
