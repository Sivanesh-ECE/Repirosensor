# RespiroSense — Bill of Materials

| # | Component | Qty | Approx. Unit Price (USD) | Notes |
|---|---|---|---|---|
| 1 | ESP32 Dev Module (WROOM-32, 30/38-pin) | 1 | $6–9 | Dual-core, Wi-Fi, ≥4MB flash |
| 2 | INMP441 I2S MEMS microphone breakout | 1 | $3–5 | Omnidirectional, 24-bit I2S out |
| 3 | MPU6050 6-axis accelerometer/gyroscope breakout | 1 | $2–4 | I2C, 0x68 |
| 4 | SSD1306 0.96" OLED display, 128x64, I2C | 1 | $3–6 | 4-pin I2C variant |
| 5 | MAX98357A I2S class-D amplifier breakout | 1 | $4–6 | 3W into 4Ω, up to ~92% efficiency |
| 6 | 4Ω 4W speaker (40mm) | 1 | $2–4 | Match to MAX98357A output |
| 7 | Breadboard (830-point) or perfboard | 1 | $3–5 | For prototyping |
| 8 | Jumper wires (M-M, M-F) | ~30 | $2–4 | |
| 9 | USB Micro-B or USB-C cable (per board) | 1 | $2–3 | For programming + 5V power |
| 10 | 5V / 2A USB power adapter | 1 | $5–8 | Sized for amplifier peak current |
| 11 | Momentary push-button (optional, external silence btn) | 1 | $0.50 | Only if not reusing onboard BOOT button |
| 12 | Enclosure (3D-printed or project box) | 1 | $5–15 | Optional, for bedside deployment |
| 13 | Mounting strap / chest band (optional) | 1 | $3–8 | For IMU placement on torso if used as wearable |

**Estimated total: $40–70** depending on sourcing and enclosure choices.

## Tools Required
- Soldering iron + solder (if using breakout boards without pre-soldered headers)
- USB data cable capable of data transfer (not charge-only)
- Computer with Arduino IDE 2.x installed
