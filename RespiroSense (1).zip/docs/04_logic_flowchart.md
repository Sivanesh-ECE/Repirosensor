# RespiroSense — Logic Flowchart

## Top-Level Boot Flow

```
        ┌──────────────┐
        │  Power on /   │
        │    Reset      │
        └──────┬───────┘
               ▼
        ┌──────────────┐
        │ loggerInit()  │  (Serial @115200)
        └──────┬───────┘
               ▼
        ┌───────────────────────┐
        │ Create mutexes/queues │
        └──────┬────────────────┘
               ▼
        ┌───────────────────────┐
        │ Wire.begin(21,22)      │
        └──────┬────────────────┘
               ▼
        ┌────────────────────────────────────┐
        │ Init: audio, motion, display, alarm, │
        │       edgeAI, fusion (each logs      │
        │       pass/fail, none halts boot)    │
        └──────┬─────────────────────────────┘
               ▼
        ┌────────────────────────────────────┐
        │ Create 8 pinned FreeRTOS tasks       │
        └──────┬─────────────────────────────┘
               ▼
        ┌───────────────────────┐
        │  loop(): blink LED     │  (tasks run independently)
        └───────────────────────┘
```

## Audio → Inference Pipeline

```
 [AudioCapture task]                       [AudioInfer task]
   │                                            │
   ▼                                            │
 i2s_read() 256 samples (16ms) ◄─ blocking      │
   │                                            │
   ▼                                            │
 Normalize int32→float PCM                      │
   │                                            │
   ▼                                            │
 256-pt FFT (Hamming window)                    │
   │                                            │
   ▼                                            │
 13-band mel filterbank → log-energy             │
   │                                            │
   ▼                                            │
 AudioFeatureFrame → queue ─────────────────────►│
                                                  ▼
                                          Dense NN (13→16 ReLU→5 softmax)
                                                  │
                                                  ▼
                                          argmax + confidence
                                                  │
                                          confidence < 0.55?
                                             │yes        │no
                                             ▼            ▼
                                        class=UNKNOWN   class=predicted
                                                  │
                                                  ▼
                                          InferenceResult → queue
```

## Motion → Respiration Pipeline

```
 [Motion task, 50 Hz]
   │
   ▼
 Read ax,ay,az,gx,gy,gz (I2C, mutex-guarded)
   │
   ▼
 Low-pass filter az (alpha=0.15)
   │
   ▼
 Peak detect (rising→falling transition,
   min spacing = 60000/RESP_MAX_BPM ms)
   │
   ▼
 Peaks within last 20s window ≥ 2?
   │yes                              │no
   ▼                                 ▼
 bpm = (peaks-1)/window_sec*60   respirationValid=false
   │
   ▼
 5-60 bpm range check → respirationValid
   │
   ▼
 Push MotionMetrics → queue (@5Hz)
```

## Sensor Fusion & Alert Escalation

```
 [Fusion task, 1 Hz]
   │
   ▼
 Pull latest InferenceResult + MotionMetrics
   │
   ▼
 audioBad = class==DISTRESS & conf≥0.55        audioMild = class∈{WHEEZE,COUGH} & conf≥0.55
   │                                                  │
   ▼                                                  ▼
 distressStreak++/-- (hysteresis)             wheezeCoughStreak++/--
   │
   ▼
 respAbnormal = bpm outside [7, 45]   respMissing = !respirationValid
 highMovement = movementStdDev > 0.35g
   │
   ▼
 ┌─────────────────────────────────────────────────────────────┐
 │ distressStreak≥6  OR (distressStreak≥3 AND (respAbnormal      │
 │   OR respMissing))                    → ALERT_CRITICAL        │
 │ distressStreak≥3 OR (audioBad AND highMovement)               │
 │                                        → ALERT_WARNING         │
 │ wheezeCoughStreak≥3 OR respAbnormal OR highMovement            │
 │                                        → ALERT_ADVISORY        │
 │ else                                   → ALERT_NONE            │
 └─────────────────────────────────────────────────────────────┘
   │
   ▼
 FusionResult → fan-out to Display / Alarm / Network queues
```

## Alarm Escalation

```
 ALERT_NONE      → amp disabled (SD=LOW), silent
 ALERT_ADVISORY  → single 660Hz/150ms chirp every ~5s (snoozable)
 ALERT_WARNING   → double 880Hz/200ms beep every ~2s (snoozable)
 ALERT_CRITICAL  → continuous 1000/1400Hz siren (NOT snoozable)
```

## Network Alerting

```
 [Network task]
   │
   ▼
 wifiEnsureConnected() every loop
   │
   ▼
 New FusionResult received?
   │yes
   ▼
 level ≥ WARNING AND (escalated OR rate-limit window elapsed)?
   │yes
   ▼
 Build message → telegramSendMessage() + webhookSendJson()
   │
   ▼
 Update lastAlertMs, lastSentLevel
```
