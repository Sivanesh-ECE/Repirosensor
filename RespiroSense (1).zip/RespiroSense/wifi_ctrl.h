#pragma once
#include <Arduino.h>
#include "config.h"

bool wifiInit();                 // starts async connection
bool wifiEnsureConnected();      // call periodically; handles reconnect
extern volatile bool g_wifiConnected;
