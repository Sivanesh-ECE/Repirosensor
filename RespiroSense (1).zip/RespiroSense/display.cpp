#include "display.h"
#include "sensor_fusion.h"
#include "wifi_ctrl.h"
#include "logger.h"
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

static const char* TAG = "DISPLAY";

static Adafruit_SSD1306 s_oled(OLED_WIDTH, OLED_HEIGHT, &Wire, OLED_RESET_PIN);
static bool s_oledReady = false;
static FusionResult s_lastFusion = { ALERT_NONE, CLASS_UNKNOWN, 0, 0, 0, false, 0 };

bool displayInit() {
  bool ok = false;
  if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(500)) == pdTRUE) {
    ok = s_oled.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR);
    if (ok) {
      s_oled.clearDisplay();
      s_oled.setTextColor(SSD1306_WHITE);
      s_oled.setTextSize(1);
      s_oled.setCursor(0, 0);
      s_oled.println(F("RespiroSense v1.0"));
      s_oled.println(F("Initializing..."));
      s_oled.display();
    }
    xSemaphoreGive(i2cMutex);
  }
  s_oledReady = ok;
  if (ok) LOGI(TAG, "SSD1306 initialized"); else LOGE(TAG, "SSD1306 init FAILED");
  return ok;
}

bool displayReinit() {
  LOGW(TAG, "Reinitializing OLED (error recovery)");
  s_oledReady = false;
  delay(20);
  return displayInit();
}

static const char* alertLabel(AlertLevel lvl) {
  switch (lvl) {
    case ALERT_NONE: return "MONITORING";
    case ALERT_ADVISORY: return "ADVISORY";
    case ALERT_WARNING: return "WARNING";
    case ALERT_CRITICAL: return "CRITICAL!";
  }
  return "?";
}

static void renderScreen(const FusionResult& fr) {
  if (!s_oledReady) return;
  if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(200)) != pdTRUE) return;

  s_oled.clearDisplay();
  s_oled.setTextSize(1);
  s_oled.setTextColor(SSD1306_WHITE);

  // Header bar
  s_oled.setCursor(0, 0);
  s_oled.print(F("RespiroSense "));
  s_oled.print(g_wifiConnected ? F("[WiFi]") : F("[----]"));

  // Alert banner (inverted when elevated)
  s_oled.setCursor(0, 12);
  if (fr.level >= ALERT_WARNING) {
    s_oled.fillRect(0, 11, OLED_WIDTH, 12, SSD1306_WHITE);
    s_oled.setTextColor(SSD1306_BLACK);
  }
  s_oled.setTextSize(1);
  s_oled.print(F("STATUS: "));
  s_oled.println(alertLabel(fr.level));
  s_oled.setTextColor(SSD1306_WHITE);

  // Audio classification
  s_oled.setCursor(0, 26);
  s_oled.print(F("Audio: "));
  s_oled.print(RESPIRO_CLASS_NAMES[fr.audioClass]);
  s_oled.print(F(" "));
  s_oled.print((int)(fr.audioConfidence * 100));
  s_oled.println(F("%"));

  // Respiration rate
  s_oled.setCursor(0, 38);
  s_oled.print(F("Resp: "));
  if (fr.respirationValid) {
    s_oled.print(fr.respirationRateBpm, 1);
    s_oled.println(F(" bpm"));
  } else {
    s_oled.println(F("-- (analyzing)"));
  }

  // Movement
  s_oled.setCursor(0, 50);
  s_oled.print(F("Move sd: "));
  s_oled.print(fr.movementStdDev, 2);
  s_oled.print(F("g  H:"));
  s_oled.print(ESP.getFreeHeap() / 1024);
  s_oled.print(F("k"));

  s_oled.display();
  xSemaphoreGive(i2cMutex);
}

void taskDisplay(void* pvParameters) {
  (void)pvParameters;
  LOGI(TAG, "taskDisplay started on core %d", xPortGetCoreID());

  for (;;) {
    if (g_fusionQueueDisplay && xQueueReceive(g_fusionQueueDisplay, &s_lastFusion, pdMS_TO_TICKS(1000)) == pdTRUE) {
      // fresh data
    }
    renderScreen(s_lastFusion);
    utilHeartbeat(HB_DISPLAY);
    vTaskDelay(pdMS_TO_TICKS(200));
  }
}
