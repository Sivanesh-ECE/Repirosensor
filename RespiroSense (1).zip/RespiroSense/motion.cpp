#include "motion.h"
#include "logger.h"
#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

static const char* TAG = "MOTION";

QueueHandle_t g_motionQueue = nullptr;

static Adafruit_MPU6050 s_mpu;
static bool s_mpuReady = false;

static LowPassFilter s_lpAz;
static RollingStats<250> s_movementStats; // 5s @ 50Hz

#define MAX_PEAK_TIMESTAMPS 32
static uint32_t s_peakTimestamps[MAX_PEAK_TIMESTAMPS];
static int s_peakCount = 0;
static float s_prevFiltered = 0;
static bool s_rising = false;
static uint32_t s_lastPeakMs = 0;

bool motionInit() {
  bool ok = false;
  if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(500)) == pdTRUE) {
    ok = s_mpu.begin(MPU6050_ADDR, &Wire);
    if (ok) {
      s_mpu.setAccelerometerRange(MPU6050_RANGE_4_G);
      s_mpu.setGyroRange(MPU6050_RANGE_500_DEG);
      s_mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
    }
    xSemaphoreGive(i2cMutex);
  }
  s_mpuReady = ok;
  s_lpAz.begin(0.15f); // smooths respiration-band motion, ~0.5-1Hz cutoff-ish
  if (ok) LOGI(TAG, "MPU6050 initialized"); else LOGE(TAG, "MPU6050 init FAILED");
  return ok;
}

bool motionReinit() {
  LOGW(TAG, "Reinitializing MPU6050 (error recovery)");
  s_mpuReady = false;
  delay(20);
  return motionInit();
}

bool motionReadSample(MotionSample& outSample) {
  if (!s_mpuReady) return false;
  bool ok = false;
  if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    sensors_event_t a, g, temp;
    ok = s_mpu.getEvent(&a, &g, &temp);
    if (ok) {
      outSample.ax = a.acceleration.x / 9.80665f;
      outSample.ay = a.acceleration.y / 9.80665f;
      outSample.az = a.acceleration.z / 9.80665f;
      outSample.gx = g.gyro.x * 57.2958f;
      outSample.gy = g.gyro.y * 57.2958f;
      outSample.gz = g.gyro.z * 57.2958f;
      outSample.timestampMs = millis();
    }
    xSemaphoreGive(i2cMutex);
  }
  return ok;
}

// Simple peak-based respiration estimator on the low-passed vertical (Z)
// acceleration channel. Assumes sensor mounted on chest/abdomen so gentle
// breathing motion modulates az. Debounces peaks to enforce a physiologic
// minimum spacing (RESP_MAX_BPM upper bound).
static void updateRespirationEstimate(float azFiltered, uint32_t nowMs) {
  bool nowRising = (azFiltered > s_prevFiltered);
  uint32_t minPeakSpacingMs = 60000UL / RESP_MAX_BPM;

  if (s_rising && !nowRising) {
    // local maximum detected
    if ((nowMs - s_lastPeakMs) > minPeakSpacingMs) {
      s_peakTimestamps[s_peakCount % MAX_PEAK_TIMESTAMPS] = nowMs;
      s_peakCount++;
      s_lastPeakMs = nowMs;
    }
  }
  s_rising = nowRising;
  s_prevFiltered = azFiltered;
}

static bool computeRespirationRate(uint32_t nowMs, float& outBpm) {
  int validCount = 0;
  uint32_t oldest = nowMs;
  int n = min(s_peakCount, MAX_PEAK_TIMESTAMPS);
  for (int i = 0; i < n; i++) {
    uint32_t ts = s_peakTimestamps[i];
    if ((nowMs - ts) <= (uint32_t)(RESP_WINDOW_SECONDS * 1000)) {
      validCount++;
      if (ts < oldest) oldest = ts;
    }
  }
  if (validCount < 2) { outBpm = 0; return false; }
  float windowSec = (float)(nowMs - oldest) / 1000.0f;
  if (windowSec < 3.0f) { outBpm = 0; return false; }
  float bpm = (validCount - 1) / windowSec * 60.0f;
  if (bpm < RESP_MIN_BPM || bpm > RESP_MAX_BPM) { outBpm = bpm; return false; }
  outBpm = bpm;
  return true;
}

void taskMotion(void* pvParameters) {
  (void)pvParameters;
  LOGI(TAG, "taskMotion started on core %d", xPortGetCoreID());
  const TickType_t period = pdMS_TO_TICKS(1000 / MOTION_SAMPLE_RATE_HZ);
  TickType_t lastWake = xTaskGetTickCount();

  int consecutiveFailures = 0;
  uint32_t lastPublishMs = 0;

  for (;;) {
    MotionSample sample;
    if (motionReadSample(sample)) {
      consecutiveFailures = 0;
      float azf = s_lpAz.update(sample.az);
      updateRespirationEstimate(azf, sample.timestampMs);

      float mag = sqrtf(sample.ax * sample.ax + sample.ay * sample.ay + sample.az * sample.az);
      s_movementStats.push(mag);

      utilHeartbeat(HB_MOTION);

      if (sample.timestampMs - lastPublishMs >= 200) { // publish metrics @5Hz
        lastPublishMs = sample.timestampMs;
        MotionMetrics metrics;
        metrics.respirationValid = computeRespirationRate(sample.timestampMs, metrics.respirationRateBpm);
        metrics.movementStdDev = s_movementStats.stddev();
        metrics.timestampMs = sample.timestampMs;
        if (g_motionQueue) {
          if (xQueueSend(g_motionQueue, &metrics, 0) != pdTRUE) {
            MotionMetrics discard;
            xQueueReceive(g_motionQueue, &discard, 0);
            xQueueSend(g_motionQueue, &metrics, 0);
          }
        }
      }
    } else {
      consecutiveFailures++;
      if (consecutiveFailures > 20) {
        LOGE(TAG, "Repeated MPU6050 read failures, attempting recovery");
        motionReinit();
        consecutiveFailures = 0;
      }
    }
    vTaskDelayUntil(&lastWake, period);
  }
}
