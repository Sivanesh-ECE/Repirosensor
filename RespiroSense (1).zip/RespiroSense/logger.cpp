#include "logger.h"
#include "utilities.h"
#include <stdarg.h>

static String s_ring[LOG_RING_BUFFER_LEN];
static int s_ringIdx = 0;
static int s_ringCount = 0;
static SemaphoreHandle_t s_logMutex = nullptr;

static const char* levelStr(LogLevel l) {
  switch (l) {
    case LOG_DEBUG: return "DBG";
    case LOG_INFO:  return "INF";
    case LOG_WARN:  return "WRN";
    case LOG_ERROR: return "ERR";
  }
  return "?";
}

void loggerInit() {
  Serial.begin(LOG_SERIAL_BAUD);
  uint32_t start = millis();
  while (!Serial && (millis() - start) < 2000) { delay(10); }
  s_logMutex = xSemaphoreCreateMutex();
  LOGI("BOOT", "%s v%s starting up", FW_NAME, FW_VERSION);
}

void loggerLog(LogLevel level, const char* tag, const char* fmt, ...) {
  char msgBuf[192];
  va_list args;
  va_start(args, fmt);
  vsnprintf(msgBuf, sizeof(msgBuf), fmt, args);
  va_end(args);

  char line[224];
  snprintf(line, sizeof(line), "[%s][%s][%s] %s",
           utilUptimeString(millis()).c_str(), levelStr(level), tag, msgBuf);

  if (s_logMutex && xSemaphoreTake(s_logMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    s_ring[s_ringIdx] = String(line);
    s_ringIdx = (s_ringIdx + 1) % LOG_RING_BUFFER_LEN;
    if (s_ringCount < LOG_RING_BUFFER_LEN) s_ringCount++;
    xSemaphoreGive(s_logMutex);
  }

  if (serialMutex && xSemaphoreTake(serialMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    Serial.println(line);
    xSemaphoreGive(serialMutex);
  } else {
    Serial.println(line);
  }
}

String loggerGetRecent() {
  String out;
  if (!s_logMutex) return out;
  if (xSemaphoreTake(s_logMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    int start = (s_ringIdx - s_ringCount + LOG_RING_BUFFER_LEN) % LOG_RING_BUFFER_LEN;
    for (int i = 0; i < s_ringCount; i++) {
      int idx = (start + i) % LOG_RING_BUFFER_LEN;
      out += s_ring[idx];
      out += "\n";
    }
    xSemaphoreGive(s_logMutex);
  }
  return out;
}
