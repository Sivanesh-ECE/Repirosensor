#include "audio.h"
#include "logger.h"
#include <driver/i2s.h>

static const char* TAG = "AUDIO";

QueueHandle_t g_audioFeatureQueue = nullptr;

static float s_vReal[AUDIO_FFT_SIZE];
static float s_vImag[AUDIO_FFT_SIZE];
static int32_t s_i2sRawBuf[AUDIO_FRAME_SAMPLES];

static bool s_i2sInstalled = false;

// ---------------------------------------------------------------------
// Self-contained radix-2 Cooley-Tukey FFT (no external library required).
// AUDIO_FFT_SIZE must be a power of two (256). Operates in-place on
// s_vReal/s_vImag. This avoids depending on any third-party FFT library
// being installed, so the sketch compiles with zero extra library setup.
// ---------------------------------------------------------------------
static void fftApplyHammingWindow(float* data, int n) {
  for (int i = 0; i < n; i++) {
    float w = 0.54f - 0.46f * cosf(2.0f * PI * i / (float)(n - 1));
    data[i] *= w;
  }
}

static void fftComputeInPlace(float* real, float* imag, int n) {
  // Bit-reversal permutation
  int j = 0;
  for (int i = 1; i < n; i++) {
    int bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      float tr = real[i]; real[i] = real[j]; real[j] = tr;
      float ti = imag[i]; imag[i] = imag[j]; imag[j] = ti;
    }
  }
  // Iterative Cooley-Tukey butterfly stages
  for (int len = 2; len <= n; len <<= 1) {
    float ang = -2.0f * PI / (float)len;
    float wr = cosf(ang), wi = sinf(ang);
    for (int i = 0; i < n; i += len) {
      float curWr = 1.0f, curWi = 0.0f;
      int half = len >> 1;
      for (int k = 0; k < half; k++) {
        float ur = real[i + k], ui = imag[i + k];
        float vr = real[i + k + half] * curWr - imag[i + k + half] * curWi;
        float vi = real[i + k + half] * curWi + imag[i + k + half] * curWr;
        real[i + k] = ur + vr;
        imag[i + k] = ui + vi;
        real[i + k + half] = ur - vr;
        imag[i + k + half] = ui - vi;
        float nextWr = curWr * wr - curWi * wi;
        float nextWi = curWr * wi + curWi * wr;
        curWr = nextWr;
        curWi = nextWi;
      }
    }
  }
}

static bool i2sMicInstall() {
  i2s_config_t i2sConfig = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
    .sample_rate = AUDIO_SAMPLE_RATE_HZ,
    .bits_per_sample = (i2s_bits_per_sample_t)AUDIO_BITS_PER_SAMPLE,
    .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
    .communication_format = (i2s_comm_format_t)(I2S_COMM_FORMAT_STAND_I2S),
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = AUDIO_DMA_BUF_COUNT,
    .dma_buf_len = AUDIO_DMA_BUF_LEN,
    .use_apll = false,
    .tx_desc_auto_clear = false,
    .fixed_mclk = 0
  };

  i2s_pin_config_t pinConfig = {
    .mck_io_num = I2S_PIN_NO_CHANGE,   // MCLK unused; must be set explicitly or
                                        // it zero-defaults to GPIO0 on some IDF
                                        // versions, colliding with the silence
                                        // button / boot-strap pin.
    .bck_io_num = PIN_I2S_MIC_SCK,
    .ws_io_num = PIN_I2S_MIC_WS,
    .data_out_num = I2S_PIN_NO_CHANGE,
    .data_in_num = PIN_I2S_MIC_SD
  };

  esp_err_t err = i2s_driver_install(I2S_NUM_0, &i2sConfig, 0, NULL);
  if (err != ESP_OK) {
    LOGE(TAG, "i2s_driver_install failed: %d", (int)err);
    return false;
  }
  err = i2s_set_pin(I2S_NUM_0, &pinConfig);
  if (err != ESP_OK) {
    LOGE(TAG, "i2s_set_pin failed: %d", (int)err);
    i2s_driver_uninstall(I2S_NUM_0);
    return false;
  }
  i2s_zero_dma_buffer(I2S_NUM_0);
  return true;
}

bool audioInit() {
  if (s_i2sInstalled) return true;
  bool ok = i2sMicInstall();
  s_i2sInstalled = ok;
  if (ok) LOGI(TAG, "I2S0 mic initialized @ %d Hz", AUDIO_SAMPLE_RATE_HZ);
  return ok;
}

bool audioReinit() {
  LOGW(TAG, "Reinitializing I2S mic driver (error recovery)");
  if (s_i2sInstalled) {
    i2s_driver_uninstall(I2S_NUM_0);
    s_i2sInstalled = false;
  }
  delay(20);
  return audioInit();
}

// Computes 13 mel-log-energy features from a time-domain frame.
static void computeMelFeatures(const float* frame, int n, float* outMel) {
  for (int i = 0; i < AUDIO_FFT_SIZE; i++) {
    s_vReal[i] = (i < n) ? frame[i] : 0.0f;
    s_vImag[i] = 0.0f;
  }
  fftApplyHammingWindow(s_vReal, AUDIO_FFT_SIZE);
  fftComputeInPlace(s_vReal, s_vImag, AUDIO_FFT_SIZE);

  // Convert first half-spectrum (DC..Nyquist, RS_FFT_BINS bins) to magnitude
  // in-place, overwriting s_vReal for the bins we need.
  for (int k = 0; k < RS_FFT_BINS; k++) {
    s_vReal[k] = sqrtf(s_vReal[k] * s_vReal[k] + s_vImag[k] * s_vImag[k]);
  }

  for (int m = 0; m < RS_MEL_FILTERS; m++) {
    float energy = 0.0f;
    const float* row = &RS_MEL_FILTERBANK[m * RS_FFT_BINS];
    for (int k = 0; k < RS_FFT_BINS; k++) {
      energy += pgm_read_float(&row[k]) * s_vReal[k];
    }
    outMel[m] = logf(energy + 1e-6f);
  }
}

bool audioCaptureFrame(AudioFeatureFrame& outFrame, uint32_t timeoutMs) {
  if (!s_i2sInstalled) return false;

  size_t bytesRead = 0;
  esp_err_t err = i2s_read(I2S_NUM_0, (void*)s_i2sRawBuf,
                            sizeof(s_i2sRawBuf), &bytesRead,
                            pdMS_TO_TICKS(timeoutMs));
  if (err != ESP_OK || bytesRead == 0) {
    return false;
  }

  int samplesRead = bytesRead / sizeof(int32_t);
  static float floatFrame[AUDIO_FRAME_SAMPLES];
  float sumSq = 0.0f;
  for (int i = 0; i < samplesRead && i < AUDIO_FRAME_SAMPLES; i++) {
    // INMP441 24-bit sample left-justified in 32-bit word.
    int32_t s24 = s_i2sRawBuf[i] >> 8;
    float norm = (float)s24 / 8388608.0f; // 2^23
    floatFrame[i] = norm;
    sumSq += norm * norm;
  }

  computeMelFeatures(floatFrame, samplesRead, outFrame.mfcc);
  outFrame.rms = sqrtf(sumSq / (float)max(1, samplesRead));
  outFrame.timestampMs = millis();
  return true;
}

void taskAudioCapture(void* pvParameters) {
  (void)pvParameters;
  LOGI(TAG, "taskAudioCapture started on core %d", xPortGetCoreID());

  int failCount = 0;
  for (;;) {
    AudioFeatureFrame frame;
    bool ok = audioCaptureFrame(frame, 200);
    if (ok) {
      failCount = 0;
      if (g_audioFeatureQueue) {
        // Overwrite oldest if consumer is behind, keep pipeline real-time.
        if (xQueueSend(g_audioFeatureQueue, &frame, 0) != pdTRUE) {
          AudioFeatureFrame discard;
          xQueueReceive(g_audioFeatureQueue, &discard, 0);
          xQueueSend(g_audioFeatureQueue, &frame, 0);
        }
      }
      utilHeartbeat(HB_AUDIO_CAPTURE);
    } else {
      failCount++;
      if (failCount > 25) {
        LOGE(TAG, "Repeated I2S read failures, attempting recovery");
        audioReinit();
        failCount = 0;
      }
    }
    vTaskDelay(pdMS_TO_TICKS(2));
  }
}
