#pragma once
#include <Arduino.h>
#include "config.h"
#include "utilities.h"

bool alarmInit();
bool alarmReinit();

// RTOS task: consumes FusionResult from g_fusionQueueAlarm and drives the
// MAX98357A amplifier with a real-time synthesized tone pattern whose
// urgency scales with AlertLevel (silence / gentle chirp / repeated beep /
// continuous urgent siren). A physical BOOT-button press silences the
// current stage for a cooldown period.
void taskAlarm(void* pvParameters);
