#pragma once
#include <Arduino.h>
#include "config.h"
#include "utilities.h"

bool motionInit();
bool motionReinit();

// Reads one accel+gyro sample (thread-safe over I2C mutex).
bool motionReadSample(MotionSample& outSample);

// RTOS task: samples MPU6050 at MOTION_SAMPLE_RATE_HZ, runs a breathing-rate
// estimator (peak counting on low-passed vertical acceleration) and a
// movement-variability estimator, publishes MotionMetrics to g_motionQueue.
void taskMotion(void* pvParameters);

extern QueueHandle_t g_motionQueue;
