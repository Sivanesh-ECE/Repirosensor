#include "edge_ai.h"
#include "audio.h"
#include "logger.h"

static const char* TAG = "EDGE_AI";

QueueHandle_t g_inferenceQueue = nullptr;

bool edgeAiInit() {
  LOGI(TAG, "Edge-AI baseline classifier ready (%d-in / %d-hidden / %d-class)",
       RS_MEL_FILTERS, RS_NN_HIDDEN, RS_NN_CLASSES);
  return true;
}

static inline float reluf(float x) { return x > 0 ? x : 0; }

bool edgeAiRunInference(const AudioFeatureFrame& features, InferenceResult& outResult) {
  float hidden[RS_NN_HIDDEN];

  // Layer 1: dense + ReLU
  for (int h = 0; h < RS_NN_HIDDEN; h++) {
    float acc = pgm_read_float(&RS_B1[h]);
    for (int i = 0; i < RS_MEL_FILTERS; i++) {
      float w = pgm_read_float(&RS_W1[i * RS_NN_HIDDEN + h]);
      acc += w * features.mfcc[i];
    }
    hidden[h] = reluf(acc);
  }

  // Layer 2: dense -> logits
  float logits[RS_NN_CLASSES];
  for (int c = 0; c < RS_NN_CLASSES; c++) {
    float acc = pgm_read_float(&RS_B2[c]);
    for (int h = 0; h < RS_NN_HIDDEN; h++) {
      float w = pgm_read_float(&RS_W2[h * RS_NN_CLASSES + c]);
      acc += w * hidden[h];
    }
    logits[c] = acc;
  }

  // Softmax
  float maxLogit = logits[0];
  for (int c = 1; c < RS_NN_CLASSES; c++) if (logits[c] > maxLogit) maxLogit = logits[c];
  float sumExp = 0;
  for (int c = 0; c < RS_NN_CLASSES; c++) {
    outResult.scores[c] = expf(logits[c] - maxLogit);
    sumExp += outResult.scores[c];
  }
  uint8_t bestClass = 0;
  float bestScore = -1;
  for (int c = 0; c < RS_NN_CLASSES; c++) {
    outResult.scores[c] /= (sumExp > 1e-9f ? sumExp : 1.0f);
    if (outResult.scores[c] > bestScore) { bestScore = outResult.scores[c]; bestClass = c; }
  }

  // Additional signal-level heuristic: very low RMS -> confidently "Normal"
  // (silence / quiet steady breathing), which stabilizes the demo weights
  // against spurious high-frequency noise classifications.
  if (features.rms < 0.004f && bestClass != CLASS_NORMAL) {
    bestClass = CLASS_NORMAL;
    bestScore = max(bestScore, 0.6f);
  }

  outResult.classId = bestClass;
  outResult.confidence = bestScore;
  outResult.timestampMs = features.timestampMs;

  if (outResult.confidence < AI_CONFIDENCE_THRESHOLD) {
    outResult.classId = CLASS_UNKNOWN;
  }
  return true;
}

void taskAudioInference(void* pvParameters) {
  (void)pvParameters;
  LOGI(TAG, "taskAudioInference started on core %d", xPortGetCoreID());

  AudioFeatureFrame frame;
  uint32_t lastInferMs = 0;

  for (;;) {
    if (g_audioFeatureQueue && xQueueReceive(g_audioFeatureQueue, &frame, pdMS_TO_TICKS(300)) == pdTRUE) {
      uint32_t now = millis();
      if (now - lastInferMs >= AI_INFERENCE_INTERVAL_MS) {
        lastInferMs = now;
        InferenceResult result;
        if (edgeAiRunInference(frame, result)) {
          utilHeartbeat(HB_AUDIO_INFER);
          if (g_inferenceQueue) {
            if (xQueueSend(g_inferenceQueue, &result, 0) != pdTRUE) {
              InferenceResult discard;
              xQueueReceive(g_inferenceQueue, &discard, 0);
              xQueueSend(g_inferenceQueue, &result, 0);
            }
          }
        }
      }
    } else {
      utilHeartbeat(HB_AUDIO_INFER); // idle wait is not a fault
    }
  }
}
