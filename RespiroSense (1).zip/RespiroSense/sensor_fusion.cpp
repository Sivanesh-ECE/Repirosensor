#include "sensor_fusion.h"
#include "edge_ai.h"
#include "audio.h"
#include "motion.h"
#include "logger.h"

static const char* TAG = "FUSION";

QueueHandle_t g_fusionQueueDisplay = nullptr;
QueueHandle_t g_fusionQueueAlarm = nullptr;
QueueHandle_t g_fusionQueueNetwork = nullptr;

static InferenceResult s_latestInference = { CLASS_UNKNOWN, 0, {0}, 0 };
static MotionMetrics s_latestMotion = { 0, 0, false, 0 };
static int s_distressStreak = 0;
static int s_wheezeCoughStreak = 0;

bool sensorFusionInit() {
  LOGI(TAG, "Sensor fusion initialized");
  return true;
}

static AlertLevel computeAlertLevel(const InferenceResult& infer, const MotionMetrics& motion) {
  bool audioBad = (infer.classId == CLASS_DISTRESS) &&
                   (infer.confidence >= AI_CONFIDENCE_THRESHOLD);
  bool audioMild = (infer.classId == CLASS_WHEEZE || infer.classId == CLASS_COUGH) &&
                    (infer.confidence >= AI_CONFIDENCE_THRESHOLD);

  bool respAbnormal = motion.respirationValid &&
                       (motion.respirationRateBpm < RESP_MIN_BPM + 2 ||
                        motion.respirationRateBpm > RESP_MAX_BPM - 15);
  bool respMissing = !motion.respirationValid; // possible apnea / sensor loss during stillness
  bool highMovement = motion.movementStdDev > MOVEMENT_STDDEV_ALERT_G;

  if (audioBad) s_distressStreak++; else s_distressStreak = max(0, s_distressStreak - 1);
  if (audioMild) s_wheezeCoughStreak++; else s_wheezeCoughStreak = max(0, s_wheezeCoughStreak - 1);

  // Sensor fusion rule set: audio distress + abnormal/missing respiration
  // sustained over several consecutive evaluation cycles escalates fastest.
  if (s_distressStreak >= DISTRESS_STREAK_FOR_CRITICAL ||
      (s_distressStreak >= DISTRESS_STREAK_FOR_WARNING && (respAbnormal || respMissing))) {
    return ALERT_CRITICAL;
  }
  if (s_distressStreak >= DISTRESS_STREAK_FOR_WARNING || (audioBad && highMovement)) {
    return ALERT_WARNING;
  }
  if (s_wheezeCoughStreak >= DISTRESS_STREAK_FOR_WARNING || respAbnormal || highMovement) {
    return ALERT_ADVISORY;
  }
  return ALERT_NONE;
}

static void publishFanout(const FusionResult& fr) {
  if (g_fusionQueueDisplay) {
    if (xQueueSend(g_fusionQueueDisplay, &fr, 0) != pdTRUE) {
      FusionResult d; xQueueReceive(g_fusionQueueDisplay, &d, 0);
      xQueueSend(g_fusionQueueDisplay, &fr, 0);
    }
  }
  if (g_fusionQueueAlarm) {
    if (xQueueSend(g_fusionQueueAlarm, &fr, 0) != pdTRUE) {
      FusionResult d; xQueueReceive(g_fusionQueueAlarm, &d, 0);
      xQueueSend(g_fusionQueueAlarm, &fr, 0);
    }
  }
  if (g_fusionQueueNetwork) {
    if (xQueueSend(g_fusionQueueNetwork, &fr, 0) != pdTRUE) {
      FusionResult d; xQueueReceive(g_fusionQueueNetwork, &d, 0);
      xQueueSend(g_fusionQueueNetwork, &fr, 0);
    }
  }
}

void taskSensorFusion(void* pvParameters) {
  (void)pvParameters;
  LOGI(TAG, "taskSensorFusion started on core %d", xPortGetCoreID());

  for (;;) {
    InferenceResult infer;
    MotionMetrics motion;
    bool gotInfer = g_inferenceQueue && xQueueReceive(g_inferenceQueue, &infer, 0) == pdTRUE;
    bool gotMotion = g_motionQueue && xQueueReceive(g_motionQueue, &motion, 0) == pdTRUE;

    if (gotInfer) s_latestInference = infer;
    if (gotMotion) s_latestMotion = motion;

    AlertLevel level = computeAlertLevel(s_latestInference, s_latestMotion);

    FusionResult fr;
    fr.level = level;
    fr.audioClass = s_latestInference.classId;
    fr.audioConfidence = s_latestInference.confidence;
    fr.respirationRateBpm = s_latestMotion.respirationRateBpm;
    fr.movementStdDev = s_latestMotion.movementStdDev;
    fr.respirationValid = s_latestMotion.respirationValid;
    fr.timestampMs = millis();

    publishFanout(fr);
    utilHeartbeat(HB_FUSION);

    vTaskDelay(pdMS_TO_TICKS(FUSION_EVAL_INTERVAL_MS));
  }
}
