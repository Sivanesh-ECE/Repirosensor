#include "telegram.h"
#include "sensor_fusion.h"
#include "wifi_ctrl.h"
#include "logger.h"
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

static const char* TAG = "NET";
static uint32_t s_lastAlertMs = 0;
static AlertLevel s_lastSentLevel = ALERT_NONE;

bool telegramSendMessage(const String& text) {
  if (strlen(TELEGRAM_BOT_TOKEN) == 0 || strcmp(TELEGRAM_BOT_TOKEN, "YOUR_TELEGRAM_BOT_TOKEN") == 0) {
    LOGD(TAG, "Telegram not configured, skipping send");
    return false;
  }
  if (!g_wifiConnected) return false;

  WiFiClientSecure client;
  client.setInsecure(); // Telegram cert validation skipped for embedded simplicity
  HTTPClient https;

  String url = String("https://") + TELEGRAM_API_HOST + "/bot" + TELEGRAM_BOT_TOKEN + "/sendMessage";
  if (!https.begin(client, url)) {
    LOGE(TAG, "Telegram https.begin() failed");
    return false;
  }
  https.addHeader("Content-Type", "application/json");

  StaticJsonDocument<512> doc;
  doc["chat_id"] = TELEGRAM_CHAT_ID;
  doc["text"] = text;
  String payload;
  serializeJson(doc, payload);

  int code = https.POST(payload);
  https.end();
  if (code > 0 && code < 300) {
    LOGI(TAG, "Telegram alert sent (HTTP %d)", code);
    return true;
  }
  LOGE(TAG, "Telegram send failed (HTTP %d)", code);
  return false;
}

bool webhookSendJson(const String& jsonPayload) {
  if (strlen(WEBHOOK_URL) == 0) return false;
  if (!g_wifiConnected) return false;

  HTTPClient http;
  if (!http.begin(WEBHOOK_URL)) return false;
  http.addHeader("Content-Type", "application/json");
  int code = http.POST(jsonPayload);
  http.end();
  if (code > 0 && code < 300) {
    LOGI(TAG, "Webhook alert sent (HTTP %d)", code);
    return true;
  }
  LOGE(TAG, "Webhook send failed (HTTP %d)", code);
  return false;
}

static String buildAlertMessage(const FusionResult& fr) {
  const char* levelStr =
      fr.level == ALERT_CRITICAL ? "CRITICAL" :
      fr.level == ALERT_WARNING  ? "WARNING"  :
      fr.level == ALERT_ADVISORY ? "ADVISORY" : "NORMAL";

  String msg = "RespiroSense Alert [" + String(levelStr) + "]\n";
  msg += "Audio class: " + String(RESPIRO_CLASS_NAMES[fr.audioClass]) +
         " (" + String((int)(fr.audioConfidence * 100)) + "%)\n";
  if (fr.respirationValid) {
    msg += "Respiration: " + String(fr.respirationRateBpm, 1) + " bpm\n";
  } else {
    msg += "Respiration: unavailable / possible apnea\n";
  }
  msg += "Movement stddev: " + String(fr.movementStdDev, 2) + " g\n";
  msg += "This is an assistive alert from a DIY monitoring device, not a "
         "certified medical device. Verify in person.";
  return msg;
}

void taskNetwork(void* pvParameters) {
  (void)pvParameters;
  LOGI(TAG, "taskNetwork started on core %d", xPortGetCoreID());

  wifiInit();

  FusionResult fr = { ALERT_NONE, CLASS_UNKNOWN, 0, 0, 0, false, 0 };

  for (;;) {
    wifiEnsureConnected();

    bool got = g_fusionQueueNetwork &&
               xQueueReceive(g_fusionQueueNetwork, &fr, pdMS_TO_TICKS(1000)) == pdTRUE;

    if (got) {
      uint32_t now = millis();
      bool escalated = (fr.level > s_lastSentLevel);
      bool rateLimitOk = (now - s_lastAlertMs) >= ALERT_MIN_INTERVAL_MS;

      if (fr.level >= ALERT_WARNING && (escalated || rateLimitOk)) {
        String msg = buildAlertMessage(fr);
        telegramSendMessage(msg);

        StaticJsonDocument<256> doc;
        doc["level"] = (int)fr.level;
        doc["audio_class"] = RESPIRO_CLASS_NAMES[fr.audioClass];
        doc["confidence"] = fr.audioConfidence;
        doc["respiration_bpm"] = fr.respirationRateBpm;
        doc["respiration_valid"] = fr.respirationValid;
        doc["movement_stddev"] = fr.movementStdDev;
        String json;
        serializeJson(doc, json);
        webhookSendJson(json);

        s_lastAlertMs = now;
      }
      s_lastSentLevel = fr.level;
    }
    utilHeartbeat(HB_NETWORK);
  }
}
