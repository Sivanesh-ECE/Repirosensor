#pragma once
#include <Arduino.h>
#include "config.h"
#include "utilities.h"

bool telegramSendMessage(const String& text);
bool webhookSendJson(const String& jsonPayload);

// RTOS task: watches g_fusionQueueNetwork for AlertLevel escalations and
// pushes rate-limited Telegram/webhook notifications. Also maintains the
// Wi-Fi connection via wifiEnsureConnected().
void taskNetwork(void* pvParameters);
