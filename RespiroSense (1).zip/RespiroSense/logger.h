#pragma once
#include <Arduino.h>
#include "config.h"

enum LogLevel : uint8_t { LOG_DEBUG = 0, LOG_INFO, LOG_WARN, LOG_ERROR };

void loggerInit();
void loggerLog(LogLevel level, const char* tag, const char* fmt, ...);
String loggerGetRecent();  // last LOG_RING_BUFFER_LEN lines, newline separated

#define LOGD(tag, fmt, ...) loggerLog(LOG_DEBUG, tag, fmt, ##__VA_ARGS__)
#define LOGI(tag, fmt, ...) loggerLog(LOG_INFO,  tag, fmt, ##__VA_ARGS__)
#define LOGW(tag, fmt, ...) loggerLog(LOG_WARN,  tag, fmt, ##__VA_ARGS__)
#define LOGE(tag, fmt, ...) loggerLog(LOG_ERROR, tag, fmt, ##__VA_ARGS__)
