// Auto-generated deterministic model coefficients for RespiroSense Edge-AI baseline classifier.
// Generated offline (seed=42). Replace with a trained Edge Impulse model for clinical-grade accuracy.
#pragma once
#include <Arduino.h>

#define RS_MEL_FILTERS 13
#define RS_FFT_BINS 129
#define RS_NN_HIDDEN 16
#define RS_NN_CLASSES 5

extern const float RS_MEL_FILTERBANK[1677] PROGMEM;
extern const float RS_W1[208] PROGMEM;
extern const float RS_B1[16] PROGMEM;
extern const float RS_W2[80] PROGMEM;
extern const float RS_B2[5] PROGMEM;
