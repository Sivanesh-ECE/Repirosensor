#include "wifi_ctrl.h"
#include "logger.h"
#include <WiFi.h>

static const char* TAG = "WIFI";

volatile bool g_wifiConnected = false;
static uint32_t s_lastAttemptMs = 0;

bool wifiInit() {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  LOGI(TAG, "Connecting to SSID '%s'...", WIFI_SSID);

  uint32_t start = millis();
  while (WiFi.status() != WL_CONNECTED && (millis() - start) < WIFI_CONNECT_TIMEOUT_MS) {
    delay(250);
  }
  g_wifiConnected = (WiFi.status() == WL_CONNECTED);
  if (g_wifiConnected) {
    LOGI(TAG, "WiFi connected, IP=%s", WiFi.localIP().toString().c_str());
  } else {
    LOGW(TAG, "WiFi connect timed out, will retry in background");
  }
  s_lastAttemptMs = millis();
  return g_wifiConnected;
}

bool wifiEnsureConnected() {
  if (WiFi.status() == WL_CONNECTED) {
    g_wifiConnected = true;
    return true;
  }
  g_wifiConnected = false;
  uint32_t now = millis();
  if (now - s_lastAttemptMs >= WIFI_RECONNECT_INTERVAL_MS) {
    s_lastAttemptMs = now;
    LOGW(TAG, "WiFi disconnected, attempting reconnect");
    WiFi.disconnect();
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  }
  return false;
}
