#pragma once
#include <Arduino.h>
#include "config.h"
#include "utilities.h"

// RespiroSense Edge-AI Inference Engine
// -----------------------------------------------------------------
// Self-contained on-device classifier: 13 mel-log-energy features ->
// 16-unit ReLU dense layer -> 5-class softmax (Normal / Wheeze / Cough /
// Distress / Unknown). Weights are baked in from model_weights.h.
//
// This engine is architected as a drop-in slot: to use a real trained
// Edge Impulse model instead, replace the body of edgeAiRunInference()
// with a call into the exported Edge Impulse SDK's run_classifier(),
// mapping its output_layer scores into InferenceResult. See README
// "Swapping in a trained Edge Impulse model" section.

bool edgeAiInit();

// Runs the classifier on a feature frame, returns true and fills
// `outResult` with class id + per-class scores + confidence.
bool edgeAiRunInference(const AudioFeatureFrame& features, InferenceResult& outResult);

// RTOS task: consumes AudioFeatureFrame from g_audioFeatureQueue, runs
// inference at AI_INFERENCE_INTERVAL_MS cadence, publishes to g_inferenceQueue.
void taskAudioInference(void* pvParameters);

extern QueueHandle_t g_inferenceQueue;
