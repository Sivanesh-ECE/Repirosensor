#include "alarm.h"
#include "sensor_fusion.h"
#include "logger.h"
#include <driver/i2s.h>

static const char* TAG = "ALARM";

static bool s_i2sSpkInstalled = false;
static uint32_t s_silenceUntilMs = 0;
static uint32_t s_lastButtonMs = 0;

static bool i2sSpeakerInstall() {
  i2s_config_t cfg = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
    .sample_rate = AUDIO_OUT_SAMPLE_RATE_HZ,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
    .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
    .communication_format = (i2s_comm_format_t)(I2S_COMM_FORMAT_STAND_I2S),
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 6,
    .dma_buf_len = 256,
    .use_apll = false,
    .tx_desc_auto_clear = true,
    .fixed_mclk = 0
  };
  i2s_pin_config_t pins = {
    .mck_io_num = I2S_PIN_NO_CHANGE,   // must be explicit; see audio.cpp note
    .bck_io_num = PIN_I2S_SPK_BCLK,
    .ws_io_num = PIN_I2S_SPK_LRC,
    .data_out_num = PIN_I2S_SPK_DIN,
    .data_in_num = I2S_PIN_NO_CHANGE
  };
  if (i2s_driver_install(I2S_NUM_1, &cfg, 0, NULL) != ESP_OK) return false;
  if (i2s_set_pin(I2S_NUM_1, &pins) != ESP_OK) {
    i2s_driver_uninstall(I2S_NUM_1);
    return false;
  }
  i2s_zero_dma_buffer(I2S_NUM_1);
  return true;
}

bool alarmInit() {
  pinMode(PIN_SPK_SD_ENABLE, OUTPUT);
  digitalWrite(PIN_SPK_SD_ENABLE, LOW); // amp disabled/idle by default
  pinMode(PIN_SILENCE_BUTTON, INPUT_PULLUP);

  bool ok = i2sSpeakerInstall();
  s_i2sSpkInstalled = ok;
  if (ok) LOGI(TAG, "I2S1 amplifier initialized"); else LOGE(TAG, "I2S1 amp init FAILED");
  return ok;
}

bool alarmReinit() {
  LOGW(TAG, "Reinitializing I2S amplifier (error recovery)");
  if (s_i2sSpkInstalled) {
    i2s_driver_uninstall(I2S_NUM_1);
    s_i2sSpkInstalled = false;
  }
  delay(20);
  return alarmInit();
}

// Synthesizes and writes `durationMs` of a sine tone at `freqHz`, blocking.
static void playTone(float freqHz, uint32_t durationMs, float amplitude) {
  if (!s_i2sSpkInstalled) return;
  digitalWrite(PIN_SPK_SD_ENABLE, HIGH);
  delay(2); // amp wake time

  const int sampleRate = AUDIO_OUT_SAMPLE_RATE_HZ;
  const int totalSamples = (sampleRate * durationMs) / 1000;
  const int chunkSamples = 128;
  int16_t chunk[chunkSamples];
  static float phase = 0.0f;
  float phaseInc = 2.0f * PI * freqHz / sampleRate;

  int samplesWritten = 0;
  while (samplesWritten < totalSamples) {
    int n = min(chunkSamples, totalSamples - samplesWritten);
    for (int i = 0; i < n; i++) {
      float s = sinf(phase) * amplitude;
      chunk[i] = (int16_t)(s * 32000.0f);
      phase += phaseInc;
      if (phase > 2.0f * PI) phase -= 2.0f * PI;
    }
    size_t bytesWritten = 0;
    i2s_write(I2S_NUM_1, chunk, n * sizeof(int16_t), &bytesWritten, pdMS_TO_TICKS(200));
    samplesWritten += n;
  }
}

static void playSilenceGap(uint32_t ms) {
  digitalWrite(PIN_SPK_SD_ENABLE, LOW);
  vTaskDelay(pdMS_TO_TICKS(ms));
}

static bool silenceButtonPressed() {
  if (digitalRead(PIN_SILENCE_BUTTON) == LOW) {
    uint32_t now = millis();
    if (now - s_lastButtonMs > 300) { // debounce
      s_lastButtonMs = now;
      return true;
    }
  }
  return false;
}

static void patternAdvisory() {
  // Single gentle chirp
  playTone(660.0f, 150, 0.25f);
  playSilenceGap(4850);
}

static void patternWarning() {
  // Double beep, moderate volume
  playTone(880.0f, 200, 0.45f);
  playSilenceGap(120);
  playTone(880.0f, 200, 0.45f);
  playSilenceGap(1600);
}

static void patternCritical() {
  // Continuous urgent two-tone siren (cannot be silenced - safety-critical)
  playTone(1000.0f, 250, 0.8f);
  playTone(1400.0f, 250, 0.8f);
}

void taskAlarm(void* pvParameters) {
  (void)pvParameters;
  LOGI(TAG, "taskAlarm started on core %d", xPortGetCoreID());

  FusionResult fr = { ALERT_NONE, CLASS_UNKNOWN, 0, 0, 0, false, 0 };

  for (;;) {
    if (g_fusionQueueAlarm) {
      xQueueReceive(g_fusionQueueAlarm, &fr, pdMS_TO_TICKS(100));
    }

    if (silenceButtonPressed() && fr.level < ALERT_CRITICAL) {
      s_silenceUntilMs = millis() + 5UL * 60UL * 1000UL; // 5 minute snooze
      LOGI(TAG, "Alarm snoozed by user for 5 minutes");
    }

    bool snoozed = (millis() < s_silenceUntilMs);

    switch (fr.level) {
      case ALERT_NONE:
        digitalWrite(PIN_SPK_SD_ENABLE, LOW);
        vTaskDelay(pdMS_TO_TICKS(200));
        break;
      case ALERT_ADVISORY:
        if (!snoozed) patternAdvisory();
        else { digitalWrite(PIN_SPK_SD_ENABLE, LOW); vTaskDelay(pdMS_TO_TICKS(200)); }
        break;
      case ALERT_WARNING:
        if (!snoozed) patternWarning();
        else { digitalWrite(PIN_SPK_SD_ENABLE, LOW); vTaskDelay(pdMS_TO_TICKS(200)); }
        break;
      case ALERT_CRITICAL:
        patternCritical(); // never snoozed: safety-critical
        break;
    }

    utilHeartbeat(HB_ALARM);
  }
}
