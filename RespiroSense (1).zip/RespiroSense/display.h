#pragma once
#include <Arduino.h>
#include "config.h"
#include "utilities.h"

bool displayInit();
bool displayReinit();

// RTOS task: reads latest FusionResult and renders a live status screen
// (respiration rate, audio class, alert banner, Wi-Fi/heap status).
void taskDisplay(void* pvParameters);
