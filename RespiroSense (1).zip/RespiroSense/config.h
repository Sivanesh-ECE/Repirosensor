/*
 * RespiroSense - AI-Powered Nocturnal Respiratory Crisis Predictor
 * config.h - Central configuration: pin mapping, constants, user settings
 *
 * PIN MAP RATIONALE (conflict-checked):
 *  - I2C bus (SDA=21 SCL=22) is shared by MPU6050 (0x68) and SSD1306 (0x3C).
 *    Different 7-bit addresses -> no bus conflict. Access is serialized with
 *    a FreeRTOS mutex (see utilities.h: i2cMutex) since two tasks touch it.
 *  - INMP441 microphone uses I2S_NUM_0 in RX-only mode (WS=25, SCK=26, SD=33).
 *  - MAX98357A amplifier uses I2S_NUM_1 in TX-only mode (BCLK=27, LRC=14, DIN=32).
 *    ESP32 has two independent I2S peripherals, so mic capture (I2S0) and
 *    tone/alarm playback (I2S1) run concurrently with zero DMA/channel conflict.
 *  - GPIO0/2/12/15 (boot strapping pins) and GPIO6-11 (internal flash) are
 *    deliberately AVOIDED for peripheral wiring. GPIO0 is reused ONLY as the
 *    (already-present) BOOT button for a debounced "silence alarm" input,
 *    which is safe because it is read long after boot completes.
 *  - GPIO34-39 are input-only on ESP32; none of our outputs use them.
 *  - GPIO13/14 (JTAG strap pins MTCK/MTMS) are used for amp control/I2S,
 *    which is safe as long as JTAG debugging is not simultaneously used
 *    (standard practice on ESP32 DevKit boards for non-JTAG designs).
 */

#pragma once
#include <Arduino.h>
#include "model_weights.h"   // RS_MEL_FILTERS, RS_FFT_BINS, RS_NN_* + coefficients

// ======================= FIRMWARE INFO =======================
#define FW_NAME        "RespiroSense"
#define FW_VERSION     "1.0.0"

// ======================= I2C BUS (shared) =====================
#define PIN_I2C_SDA        21
#define PIN_I2C_SCL        22
#define I2C_CLOCK_HZ       400000UL
#define MPU6050_ADDR       0x68
#define OLED_ADDR          0x3C
#define OLED_WIDTH         128
#define OLED_HEIGHT        64
#define OLED_RESET_PIN     -1   // shares ESP32 reset, no dedicated pin

// ======================= I2S MICROPHONE (INMP441) - I2S_NUM_0 ===
#define PIN_I2S_MIC_WS     25   // Word Select / LRCLK
#define PIN_I2S_MIC_SCK    26   // Bit clock / BCLK
#define PIN_I2S_MIC_SD     33   // Serial data OUT of mic, IN to ESP32
// INMP441 L/R pin must be hard-wired to GND on the board (selects left
// channel / mono). Not a GPIO -- documented in wiring diagram.

#define AUDIO_SAMPLE_RATE_HZ   16000
#define AUDIO_BITS_PER_SAMPLE  32     // INMP441 outputs 24-bit in a 32-bit frame
#define AUDIO_DMA_BUF_COUNT    8
#define AUDIO_DMA_BUF_LEN      256    // samples per DMA buffer
#define AUDIO_FRAME_SAMPLES    256    // analysis frame (16 ms @ 16kHz)
#define AUDIO_FFT_SIZE         256    // must match model_weights.h (RS_FFT_BINS-1)*2

// ======================= I2S AMPLIFIER (MAX98357A) - I2S_NUM_1 ==
#define PIN_I2S_SPK_BCLK   27
#define PIN_I2S_SPK_LRC    14
#define PIN_I2S_SPK_DIN    32
#define PIN_SPK_SD_ENABLE  13   // MAX98357A SD pin: HIGH=enabled, LOW=shutdown
                                  // (used for power saving between alarms)
// MAX98357A GAIN pin left floating on hardware -> default 9dB gain.

#define AUDIO_OUT_SAMPLE_RATE_HZ  16000

// ======================= MOTION SENSOR (MPU6050) ==================
#define PIN_MPU_INT        4    // optional motion-interrupt (data-ready)

// ======================= USER CONTROLS / STATUS =====================
#define PIN_SILENCE_BUTTON 0    // reuse BOOT button (active LOW, debounced)
#define PIN_STATUS_LED     2    // onboard LED, general heartbeat/status

// ======================= WI-FI =======================
// EDIT THESE for your network before flashing.
#define WIFI_SSID          "YOUR_WIFI_SSID"
#define WIFI_PASSWORD      "YOUR_WIFI_PASSWORD"
#define WIFI_CONNECT_TIMEOUT_MS   15000
#define WIFI_RECONNECT_INTERVAL_MS 10000

// ======================= TELEGRAM / WEBHOOK ALERTS =======================
// EDIT THESE with your bot token & chat id (https://core.telegram.org/bots)
#define TELEGRAM_BOT_TOKEN   "YOUR_TELEGRAM_BOT_TOKEN"
#define TELEGRAM_CHAT_ID     "YOUR_TELEGRAM_CHAT_ID"
#define TELEGRAM_API_HOST    "api.telegram.org"

// Generic webhook fallback (e.g. IFTTT / n8n / Home Assistant). Leave empty
// string "" to disable.
#define WEBHOOK_URL           ""

#define ALERT_MIN_INTERVAL_MS  30000   // rate-limit outbound alerts

// ======================= RESPIRATION / MOTION ANALYSIS =======================
#define MOTION_SAMPLE_RATE_HZ      50
#define RESP_WINDOW_SECONDS        20      // sliding window for breath-rate estimate
#define RESP_MIN_BPM                5
#define RESP_MAX_BPM                60
#define MOVEMENT_STDDEV_ALERT_G     0.35f  // excessive-movement threshold

// ======================= AI / CLASSIFICATION =======================
enum RespiroClass : uint8_t {
  CLASS_NORMAL = 0,
  CLASS_WHEEZE = 1,
  CLASS_COUGH = 2,
  CLASS_DISTRESS = 3,
  CLASS_UNKNOWN = 4,
  CLASS_COUNT = 5
};

static const char* const RESPIRO_CLASS_NAMES[CLASS_COUNT] = {
  "Normal", "Wheeze", "Cough", "Distress", "Unknown"
};

#define AI_CONFIDENCE_THRESHOLD    0.55f
#define AI_INFERENCE_INTERVAL_MS   1000

// ======================= SENSOR FUSION / ALARM STAGES =======================
enum AlertLevel : uint8_t {
  ALERT_NONE = 0,
  ALERT_ADVISORY = 1,   // stage 1: mild anomaly, gentle tone
  ALERT_WARNING  = 2,   // stage 2: repeated moderate alarm
  ALERT_CRITICAL = 3    // stage 3: continuous urgent alarm + push alert
};

#define FUSION_EVAL_INTERVAL_MS    1000
#define DISTRESS_STREAK_FOR_WARNING   3   // consecutive distress-like frames
#define DISTRESS_STREAK_FOR_CRITICAL  6

// ======================= FREE RTOS TASK CONFIG =======================
#define TASK_STACK_AUDIO_CAPTURE   4096
#define TASK_STACK_AUDIO_INFER     6144
#define TASK_STACK_MOTION          3072
#define TASK_STACK_FUSION          3072
#define TASK_STACK_DISPLAY         3072
#define TASK_STACK_ALARM           3072
#define TASK_STACK_NETWORK         6144
#define TASK_STACK_WATCHDOG        2048

#define TASK_PRIO_AUDIO_CAPTURE    6   // high enough to preempt app tasks, but
                                         // deliberately below ESP32-Arduino's
                                         // internal WiFi/LWIP system tasks
                                         // (typically ~18-23) so Wi-Fi isn't
                                         // starved when audio data is ready
#define TASK_PRIO_AUDIO_INFER      3
#define TASK_PRIO_MOTION           3
#define TASK_PRIO_FUSION           2
#define TASK_PRIO_DISPLAY          1
#define TASK_PRIO_ALARM            4   // must preempt to keep alarm timing tight
#define TASK_PRIO_NETWORK          1
#define TASK_PRIO_WATCHDOG         2

#define CORE_AUDIO   0
#define CORE_APP     1

// ======================= LOGGING =======================
#define LOG_SERIAL_BAUD    115200
#define LOG_RING_BUFFER_LEN 40

// ======================= MISC =======================
#define WATCHDOG_TIMEOUT_S     8
#define HEARTBEAT_STALE_MS     5000
