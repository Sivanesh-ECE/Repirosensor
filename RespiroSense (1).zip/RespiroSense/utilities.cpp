#include "utilities.h"

SemaphoreHandle_t i2cMutex = nullptr;
SemaphoreHandle_t serialMutex = nullptr;
volatile uint32_t g_heartbeat[HB_COUNT] = {0};

void utilHeartbeat(HeartbeatId id) {
  if (id < HB_COUNT) g_heartbeat[id] = millis();
}

bool utilIsTaskStale(HeartbeatId id, uint32_t maxAgeMs) {
  if (id >= HB_COUNT) return false;
  uint32_t last = g_heartbeat[id];
  if (last == 0) return false; // not started yet, not "stale"
  return (millis() - last) > maxAgeMs;
}

float utilMapFloat(float x, float inMin, float inMax, float outMin, float outMax) {
  if (inMax - inMin == 0) return outMin;
  float t = (x - inMin) / (inMax - inMin);
  t = utilClampFloat(t, 0.0f, 1.0f);
  return outMin + t * (outMax - outMin);
}

float utilClampFloat(float x, float lo, float hi) {
  if (x < lo) return lo;
  if (x > hi) return hi;
  return x;
}

String utilUptimeString(uint32_t ms) {
  uint32_t totalSec = ms / 1000;
  uint32_t h = totalSec / 3600;
  uint32_t m = (totalSec % 3600) / 60;
  uint32_t s = totalSec % 60;
  char buf[12];
  snprintf(buf, sizeof(buf), "%02u:%02u:%02u", (unsigned)h, (unsigned)m, (unsigned)s);
  return String(buf);
}
