#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <math.h>
// Explicit FreeRTOS includes: on some ESP32 Arduino core versions these
// types/macros (SemaphoreHandle_t, QueueHandle_t, TaskHandle_t,
// configMAX_PRIORITIES, pdMS_TO_TICKS, etc.) are only reliably visible if
// pulled in directly rather than depending on Arduino.h's transitive
// include chain. Including them here (utilities.h is included by nearly
// every module) makes the whole project independent of that chain.
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "freertos/queue.h"
#include "config.h"

// ---------- Shared RTOS primitives (defined in utilities.cpp) ----------
extern SemaphoreHandle_t i2cMutex;      // guards shared I2C bus (MPU6050 + OLED)
extern SemaphoreHandle_t serialMutex;   // guards Serial prints across tasks

// Per-task heartbeat timestamps (millis) used by the watchdog task.
enum HeartbeatId : uint8_t {
  HB_AUDIO_CAPTURE = 0,
  HB_AUDIO_INFER,
  HB_MOTION,
  HB_FUSION,
  HB_DISPLAY,
  HB_ALARM,
  HB_NETWORK,
  HB_COUNT
};
extern volatile uint32_t g_heartbeat[HB_COUNT];
void utilHeartbeat(HeartbeatId id);
bool utilIsTaskStale(HeartbeatId id, uint32_t maxAgeMs);

// ---------- Cross-module data structures ----------
struct AudioFeatureFrame {
  float mfcc[RS_MEL_FILTERS];
  float rms;
  uint32_t timestampMs;
};

struct InferenceResult {
  uint8_t classId;
  float confidence;
  float scores[CLASS_COUNT];
  uint32_t timestampMs;
};

struct MotionSample {
  float ax, ay, az;   // g
  float gx, gy, gz;   // deg/s
  uint32_t timestampMs;
};

struct MotionMetrics {
  float respirationRateBpm;
  float movementStdDev;
  bool respirationValid;
  uint32_t timestampMs;
};

struct FusionResult {
  AlertLevel level;
  uint8_t audioClass;
  float audioConfidence;
  float respirationRateBpm;
  float movementStdDev;
  bool respirationValid;
  uint32_t timestampMs;
};

// ---------- Simple numeric helpers ----------
float utilMapFloat(float x, float inMin, float inMax, float outMin, float outMax);
float utilClampFloat(float x, float lo, float hi);

// Lightweight IIR low-pass filter (single pole), used for accel smoothing.
struct LowPassFilter {
  float alpha;
  float state;
  bool initialized;
  void begin(float alphaVal) { alpha = alphaVal; state = 0; initialized = false; }
  float update(float x) {
    if (!initialized) { state = x; initialized = true; }
    state = alpha * x + (1.0f - alpha) * state;
    return state;
  }
};

// Running mean/stddev over a fixed-size circular buffer.
template <int N>
struct RollingStats {
  float buf[N];
  int count = 0;
  int idx = 0;
  void push(float v) {
    buf[idx] = v;
    idx = (idx + 1) % N;
    if (count < N) count++;
  }
  float mean() const {
    if (count == 0) return 0;
    float s = 0;
    for (int i = 0; i < count; i++) s += buf[i];
    return s / count;
  }
  float stddev() const {
    if (count < 2) return 0;
    float m = mean();
    float s = 0;
    for (int i = 0; i < count; i++) { float d = buf[i] - m; s += d * d; }
    return sqrtf(s / count);
  }
  bool full() const { return count == N; }
};

// Formats a millis() timestamp as HH:MM:SS since boot.
String utilUptimeString(uint32_t ms);
