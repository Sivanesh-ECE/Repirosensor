#pragma once
#include <Arduino.h>
#include "config.h"
#include "utilities.h"

// Initializes I2S0 peripheral in RX mode for the INMP441 microphone.
// Returns true on success.
bool audioInit();

// Reads one analysis frame (AUDIO_FRAME_SAMPLES samples) from the I2S DMA
// buffer (blocking up to timeoutMs), converts to normalized float PCM,
// computes FFT + mel-filterbank features, and fills `outFrame`.
// Returns true if a valid frame was produced.
bool audioCaptureFrame(AudioFeatureFrame& outFrame, uint32_t timeoutMs);

// Attempts to recover the I2S peripheral after a DMA/read failure.
bool audioReinit();

// RTOS task entry: continuously captures frames and pushes AudioFeatureFrame
// onto the feature queue (g_audioFeatureQueue) for the inference task.
void taskAudioCapture(void* pvParameters);

extern QueueHandle_t g_audioFeatureQueue;
