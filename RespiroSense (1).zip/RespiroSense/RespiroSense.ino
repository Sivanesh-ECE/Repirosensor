/*
 * ===================================================================
 *  RespiroSense - AI-Powered Nocturnal Respiratory Crisis Predictor
 * ===================================================================
 *  Board:  ESP32 Dev Module
 *  Author: Principal Embedded Systems / Biomedical AI design
 *
 *  See docs/README.md for full wiring, architecture, and setup guide.
 *
 *  DISCLAIMER: This is a DIY assistive monitoring project. It is NOT a
 *  certified medical device and must not be used as the sole means of
 *  detecting a medical emergency. Always seek professional medical care.
 * ===================================================================
 */

#include "config.h"
#include "utilities.h"
#include "logger.h"
#include "audio.h"
#include "motion.h"
#include "edge_ai.h"
#include "sensor_fusion.h"
#include "display.h"
#include "alarm.h"
#include "wifi_ctrl.h"
#include "telegram.h"

// NOTE: The ESP-IDF hardware Task Watchdog API (esp_task_wdt_*) changed
// signature between ESP32 Arduino core 2.x and 3.x. To keep this project
// compiling identically across both without conditional #ifdefs, error
// recovery is implemented entirely with the portable heartbeat mechanism
// in utilities.h/.cpp (see taskWatchdog below). If you want the hardware
// TWDT as well, see docs/README.md "Optional hardware watchdog" section.

// ---------------------------------------------------------------
// Task handles
// ---------------------------------------------------------------
static TaskHandle_t h_audioCapture, h_audioInfer, h_motion, h_fusion,
                     h_display, h_alarm, h_network, h_watchdog;

// ---------------------------------------------------------------
// Watchdog / error-recovery task
// ---------------------------------------------------------------
static void taskWatchdog(void* pvParameters) {
  (void)pvParameters;
  LOGI("WDT", "taskWatchdog started on core %d", xPortGetCoreID());

  for (;;) {
    if (utilIsTaskStale(HB_AUDIO_CAPTURE, HEARTBEAT_STALE_MS)) {
      LOGE("WDT", "Audio capture stalled -> reinitializing I2S mic");
      audioReinit();
    }
    if (utilIsTaskStale(HB_MOTION, HEARTBEAT_STALE_MS)) {
      LOGE("WDT", "Motion task stalled -> reinitializing MPU6050");
      motionReinit();
    }
    if (utilIsTaskStale(HB_DISPLAY, HEARTBEAT_STALE_MS)) {
      LOGE("WDT", "Display task stalled -> reinitializing OLED");
      displayReinit();
    }
    if (utilIsTaskStale(HB_ALARM, HEARTBEAT_STALE_MS)) {
      LOGE("WDT", "Alarm task stalled -> reinitializing amplifier I2S");
      alarmReinit();
    }
    if (utilIsTaskStale(HB_NETWORK, HEARTBEAT_STALE_MS * 2)) {
      LOGW("WDT", "Network task quiet (may be normal if WiFi unavailable)");
    }

    LOGD("WDT", "Heap free: %u bytes", (unsigned)ESP.getFreeHeap());
    vTaskDelay(pdMS_TO_TICKS(2000));
  }
}

void setup() {
  loggerInit();
  LOGI("BOOT", "Free heap at boot: %u bytes", (unsigned)ESP.getFreeHeap());

  // ---- Shared RTOS primitives ----
  i2cMutex = xSemaphoreCreateMutex();
  serialMutex = xSemaphoreCreateMutex();

  // ---- Queues ----
  g_audioFeatureQueue   = xQueueCreate(4, sizeof(AudioFeatureFrame));
  g_inferenceQueue      = xQueueCreate(4, sizeof(InferenceResult));
  g_motionQueue         = xQueueCreate(4, sizeof(MotionMetrics));
  g_fusionQueueDisplay  = xQueueCreate(2, sizeof(FusionResult));
  g_fusionQueueAlarm    = xQueueCreate(2, sizeof(FusionResult));
  g_fusionQueueNetwork  = xQueueCreate(4, sizeof(FusionResult));

  // ---- I2C bus (shared: MPU6050 + SSD1306) ----
  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);
  Wire.setClock(I2C_CLOCK_HZ);

  // ---- Peripheral init (each is fault-tolerant; failures are logged and
  //      retried later by the watchdog task rather than halting boot) ----
  bool okAudio = audioInit();
  bool okMotion = motionInit();
  bool okDisplay = displayInit();
  bool okAlarm = alarmInit();
  bool okAI = edgeAiInit();
  bool okFusion = sensorFusionInit();

  LOGI("BOOT", "Peripheral init: audio=%d motion=%d display=%d alarm=%d ai=%d fusion=%d",
       okAudio, okMotion, okDisplay, okAlarm, okAI, okFusion);

  // ---- FreeRTOS tasks, pinned per hardware_architecture.md plan ----
  xTaskCreatePinnedToCore(taskAudioCapture, "AudioCapture", TASK_STACK_AUDIO_CAPTURE,
                           NULL, TASK_PRIO_AUDIO_CAPTURE, &h_audioCapture, CORE_AUDIO);
  xTaskCreatePinnedToCore(taskAudioInference, "AudioInfer", TASK_STACK_AUDIO_INFER,
                           NULL, TASK_PRIO_AUDIO_INFER, &h_audioInfer, CORE_AUDIO);
  xTaskCreatePinnedToCore(taskAlarm, "Alarm", TASK_STACK_ALARM,
                           NULL, TASK_PRIO_ALARM, &h_alarm, CORE_AUDIO);

  xTaskCreatePinnedToCore(taskMotion, "Motion", TASK_STACK_MOTION,
                           NULL, TASK_PRIO_MOTION, &h_motion, CORE_APP);
  xTaskCreatePinnedToCore(taskSensorFusion, "Fusion", TASK_STACK_FUSION,
                           NULL, TASK_PRIO_FUSION, &h_fusion, CORE_APP);
  xTaskCreatePinnedToCore(taskDisplay, "Display", TASK_STACK_DISPLAY,
                           NULL, TASK_PRIO_DISPLAY, &h_display, CORE_APP);
  xTaskCreatePinnedToCore(taskNetwork, "Network", TASK_STACK_NETWORK,
                           NULL, TASK_PRIO_NETWORK, &h_network, CORE_APP);

  xTaskCreatePinnedToCore(taskWatchdog, "Watchdog", TASK_STACK_WATCHDOG,
                           NULL, TASK_PRIO_WATCHDOG, &h_watchdog, CORE_APP);

  pinMode(PIN_STATUS_LED, OUTPUT);

  LOGI("BOOT", "All tasks created. RespiroSense running.");
}

void loop() {
  // All real work happens in FreeRTOS tasks. loop() only provides a slow
  // heartbeat blink so a hung Arduino loop() is visibly detectable.
  digitalWrite(PIN_STATUS_LED, !digitalRead(PIN_STATUS_LED));
  delay(1000);
}
