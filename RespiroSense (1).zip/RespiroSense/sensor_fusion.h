#pragma once
#include <Arduino.h>
#include "config.h"
#include "utilities.h"

bool sensorFusionInit();

// RTOS task: merges latest InferenceResult + MotionMetrics into a
// FusionResult with a graded AlertLevel, applying temporal hysteresis
// (consecutive-frame streaks) to avoid single-frame false alarms.
// Publishes to the three fan-out queues below (consumed by the
// display/alarm/network tasks respectively).
void taskSensorFusion(void* pvParameters);

// Fusion output is fanned out to three independent single-consumer queues.
extern QueueHandle_t g_fusionQueueDisplay;
extern QueueHandle_t g_fusionQueueAlarm;
extern QueueHandle_t g_fusionQueueNetwork;
